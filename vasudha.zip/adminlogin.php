<?php
	session_start();
	include('header.html');
?>

<html>
<body>
		<h1 align="center">Welcome to Login Panel</h1>
		
		<form action="adminlogin1.php" method="post">
		<table align="center">
		<tr>
			<td colspan="2" align="center">
				<?php	
					if(isset($_SESSION['err']))
						echo $_SESSION['err'];
				?>
			</td>
		</tr>
		<tr>
		
			<td >Username</td>
			<td><input type="text" name="user">
			<?php	
					if(isset($_SESSION['user']))
						echo $_SESSION['user'];
			?>
			</td>
		</tr>
		
		<tr>
			<td> Password</td>
			<td><input type="password" name="pass">
			<?php
				if(isset($_SESSION['pass']))
						echo $_SESSION['pass'];
			?></td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<input type="submit" name="sb" value="Login">
				<input type="reset" name="sb" value="Reset"></td>
		</tr>
		<tr>
			<td align="center" colspan="2"> <a href="signup.php"> Click here to Sign up!</a></td>
		</tr>
		</table>
		</form>
</body>
<?php
	$_SESSION['user']="";
	$_SESSION['pass']="";
	$_SESSION['err']="";
	include('footer.html');
?>