<?php
	include('header.html');
?>

	<h1 align="center">Welcome</h1>

<?php
	include('footer.html');
?>
	